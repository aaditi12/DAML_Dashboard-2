import pickle
import pandas as pd


def load_model():
    """
    Load trained model and scaler
    """
    with open("models/regression_model.pkl", "rb") as f:
        model = pickle.load(f)

    with open("models/scaler.pkl", "rb") as f:
        scaler = pickle.load(f)

    return model, scaler


def preprocess_input(input_data, training_columns):
    """
    Preprocess new input data to match training features
    """
    df = pd.DataFrame([input_data])

    # One-hot encode
    df_encoded = pd.get_dummies(df)

    # Align columns with training data
    df_encoded = df_encoded.reindex(
        columns=training_columns,
        fill_value=0
    )

    return df_encoded


def predict_admission(input_data, training_columns):
    """
    Predict admission probability
    """
    model, scaler = load_model()

    X = preprocess_input(input_data, training_columns)
    X_scaled = scaler.transform(X)

    prediction = model.predict(X_scaled)
    return prediction[0]


if __name__ == "__main__":
    # Example input (new student)
    new_student = {
        "age": 18,
        "gender": "male",
        "category": "general",
        "state": "Maharashtra",
        "preferred_stream": "Engineering",
        "entrance_exam": "JEE",
        "entrance_score": 85,
        "board_percentage": 90,
        "extracurricular_score": 7,
        "admission_status": 1,
        "scholarship_eligibility": 1
    }

    # IMPORTANT:
    # Save X.columns from training and paste them here
    training_columns = []  # <-- replace with actual columns list

    result = predict_admission(new_student, training_columns)
    print("Predicted Admission Probability:", round(result, 2))
