import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os


st.write("Current working directory:")
st.write(os.getcwd())

st.write("Files here:")
st.write(os.listdir())


st.set_page_config(page_title="University Admissions Dashboard", layout="wide")

st.title("🎓 University Admissions Dashboard")

# Load data
df = pd.read_csv(
    r"C:\Users\AADITI\Downloads\University_Admission_Prediction\data_1\College_Admission.csv"
)



# Sidebar filters
st.sidebar.header("Filters")

stream = st.sidebar.multiselect(
    "Preferred Stream",
    df["preferred_stream"].unique(),
    default=df["preferred_stream"].unique()
)

gender = st.sidebar.multiselect(
    "Gender",
    df["gender"].unique(),
    default=df["gender"].unique()
)

filtered_df = df[
    (df["preferred_stream"].isin(stream)) &
    (df["gender"].isin(gender))
]

# Layout
col1, col2 = st.columns(2)

with col1:
    st.subheader("Admission Probability Distribution")
    fig, ax = plt.subplots()
    sns.histplot(filtered_df["admission_probability"], kde=True, ax=ax)
    st.pyplot(fig)

with col2:
    st.subheader("Entrance Score vs Admission Probability")
    fig, ax = plt.subplots()
    sns.scatterplot(
        x="entrance_score",
        y="admission_probability",
        data=filtered_df,
        ax=ax
    )
    st.pyplot(fig)

# Full-width plots
st.subheader("Preferred Stream vs Admission Probability")
fig, ax = plt.subplots(figsize=(8,4))
sns.barplot(
    x="preferred_stream",
    y="admission_probability",
    data=filtered_df,
    ax=ax
)
plt.xticks(rotation=45)
st.pyplot(fig)

st.subheader("Correlation Heatmap")
fig, ax = plt.subplots(figsize=(10,6))
sns.heatmap(
    filtered_df.corr(numeric_only=True),
    annot=True,
    cmap="coolwarm",
    ax=ax
)
st.pyplot(fig)
